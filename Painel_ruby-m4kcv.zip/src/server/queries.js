import HttpError from '@wasp/core/HttpError.js'

export const getMessages = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Message.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.User.findUnique({
    where: { id: context.user.id },
    select: {
      id: true,
      username: true,
      password: false,
      messages: true
    }
  });
}