import HttpError from '@wasp/core/HttpError.js'

export const sendMessage = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({
    where: { id: context.user.id }
  });

  const message = await context.entities.Message.create({
    data: {
      content: args.content,
      sentByUser: true,
      user: { connect: { id: user.id } }
    }
  });

  return message;
}

export const trainLLM = async (args, context) => {
  // Replace this comment with the real implementation
}