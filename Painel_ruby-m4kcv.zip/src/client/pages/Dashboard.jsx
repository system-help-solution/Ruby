import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getMessages from '@wasp/queries/getMessages';
import sendMessage from '@wasp/actions/sendMessage';

export function DashboardPage() {
  const { data: messages, isLoading, error } = useQuery(getMessages);
  const sendMessageFn = useAction(sendMessage);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleSendMessage = () => {
    sendMessageFn({ content: 'Hello, LLM!' });
  };

  return (
    <div className='p-4'>
      <div className='mb-4'>
        <button
          onClick={handleSendMessage}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Send Message
        </button>
      </div>
      <div>
        {messages.map((message) => (
          <div
            key={message.id}
            className='bg-gray-100 p-4 mb-4 rounded-lg'
          >
            <div>{message.content}</div>
            <div>{message.sentByUser ? 'Sent by User' : 'Sent by LLM'}</div>
          </div>
        ))}
      </div>
      <Link to='/train' className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4'>Train LLM</Link>
    </div>
  );
}