import React, { useState } from 'react';
import { useAction } from '@wasp/actions';
import trainLLM from '@wasp/actions/trainLLM';

export function TrainLLM() {
  const trainLLMFn = useAction(trainLLM);
  const [trainingData, setTrainingData] = useState('');

  const handleTrainLLM = () => {
    trainLLMFn({ data: trainingData });
    setTrainingData('');
  };

  return (
    <div className='p-4'>
      <textarea
        className='w-full h-40 p-2 border rounded'
        value={trainingData}
        onChange={(e) => setTrainingData(e.target.value)}
        placeholder='Enter training data'
      ></textarea>
      <button
        onClick={handleTrainLLM}
        className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4'
      >
        Train LLM
      </button>
    </div>
  );
}