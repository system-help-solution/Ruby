import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getMessages from '@wasp/queries/getMessages';
import createMessage from '@wasp/actions/createMessage';

export function Conversation() {
  const { conversationId } = useParams();
  const { data: messages, isLoading, error } = useQuery(getMessages, { conversationId });
  const createMessageFn = useAction(createMessage);
  const [newMessage, setNewMessage] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateMessage = () => {
    createMessageFn({ conversationId, text: newMessage, isUserMessage: true });
    setNewMessage('');
  };

  return (
    <div className='p-4'>
      {messages.map((message) => (
        <div key={message.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{message.text}</div>
        </div>
      ))}
      <div className='flex gap-x-4 py-5'>
        <input
          type='text'
          placeholder='New Message'
          className='px-1 py-2 border rounded text-lg'
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button
          onClick={handleCreateMessage}
          className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
        >
          Send
        </button>
      </div>
      <Link to='/dashboard' className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'>
        Back to Dashboard
      </Link>
    </div>
  );
}