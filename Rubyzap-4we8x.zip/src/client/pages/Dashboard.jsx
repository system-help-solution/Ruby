import React from 'react';
import { Link } from 'react-router-dom';


export function Dashboard() {
  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Project Ruby - AI Chatbot for WhatsApp with LLM</h1>
      <p>Project Ruby is an exciting initiative aimed at creating a chatbot with Artificial Intelligence (AI) based on Language Model Machine Learning (LLM) technology. This chatbot has the ability to interact in a gentle and efficient manner with customers on WhatsApp, using an unofficial API such as Abayils or Evolution-API.</p>
      <h2 className='text-2xl font-bold mt-8 mb-4'>Key Features</h2>
      <ul className='list-disc list-inside'>
        <li>Custom AI: The Ruby chatbot is customized for your company. It learns from you and adapts to your organization's needs, becoming an intelligent extension of your customer service.</li>
        <li>Web Server and Control Panel: Project Ruby is deployed on a web server, providing flexible access. Additionally, it offers an intuitive and visually appealing control panel, allowing you to manage, edit, and view customer interactions.</li>
        <li>Integrated CRM: The Ruby chatbot includes CRM functionalities, making it easy to track, manage, and analyze customer conversations. This helps improve customer relationships and enhance operational efficiency.</li>
        <li>Intelligent Flow: Based on advanced LLM technology, the Ruby chatbot is capable of creating smart and dynamic conversation flows, providing your customers with an enhanced and personalized customer service experience.</li>
      </ul>
      <h2 className='text-2xl font-bold mt-8 mb-4'>Objectives</h2>
      <p>Project Ruby aims to create a high-quality chatbot for WhatsApp that is customized, efficient, and capable of adapting to your company's needs. Its goal is to enhance customer service, increase customer satisfaction, and save time and resources.</p>
      <p>Join us on this exciting journey to transform how you interact with your customers on WhatsApp. With Project Ruby, you'll have an innovative and highly effective customer service solution.</p>
    </div>
  );
}