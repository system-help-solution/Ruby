import HttpError from '@wasp/core/HttpError.js'

export const createMessage = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const user = await context.entities.User.findUnique({
    where: { id: context.user.id }
  })

  const message = await context.entities.Message.create({
    data: {
      text: args.text,
      isUserMessage: args.isUserMessage,
      conversation: {
        connect: { id: user.conversation.id }
      }
    }
  })

  return message
}

export const createConversation = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Conversation.create({
    data: {
      user: { connect: { id: context.user.id } }
    }
  });
}
