import HttpError from '@wasp/core/HttpError.js'

export const getConversations = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Conversation.findMany({
    where: { user: { id: context.user.id } },
    include: { messages: true }
  });
}

export const getMessages = async ({ conversationId }, context) => {
  if (!context.user) throw new HttpError(401);

  const conversation = await context.entities.Conversation.findUnique({
    where: { id: conversationId },
    include: { messages: true }
  });

  if (!conversation) throw new HttpError(400);
  if (conversation.user.id !== context.user.id) throw new HttpError(400);

  return conversation.messages;
}