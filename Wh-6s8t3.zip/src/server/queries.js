import HttpError from '@wasp/core/HttpError.js'

export const getUserChats = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const userId = context.user.id;

  return context.entities.Chat.findMany({
    where: { userId }
  });
}

export const getChatMessages = async ({ chatId }, context) => {
  if (!context.user) throw new HttpError(401);

  const messages = await context.entities.Message.findMany({
    where: { chat: { id: chatId } },
    include: { chat: true }
  });

  if (!messages) throw new HttpError(404, `No messages found for chat with id ${chatId}`);

  return messages;
}
