import HttpError from '@wasp/core/HttpError.js'

export const createChat = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const newChat = await context.entities.Chat.create({
    data: {
      userId: context.user.id
    }
  })

  return newChat
}

export const createMessage = async ({ chatId, content }, context) => {
  // Check if user is authenticated
  if (!context.user) { throw new HttpError(401) }

  // Check if chat exists
  const chat = await context.entities.Chat.findUnique({
    where: { id: chatId }
  })
  if (!chat) { throw new HttpError(404, 'Chat not found') }

  // Check if user is authorized to create message in this chat
  if (chat.userId !== context.user.id) { throw new HttpError(403, 'User not authorized') }

  // Create the message
  const message = await context.entities.Message.create({
    data: {
      chat: { connect: { id: chatId } },
      content
    }
  })

  return message
}