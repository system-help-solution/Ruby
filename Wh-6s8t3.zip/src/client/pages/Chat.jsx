import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getChatMessages from '@wasp/queries/getChatMessages';
import createMessage from '@wasp/actions/createMessage';

export function Chat() {
  const { chatId } = useParams();
  const { data: messages, isLoading, error } = useQuery(getChatMessages, { chatId });
  const createMessageFn = useAction(createMessage);
  const [newMessage, setNewMessage] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateMessage = () => {
    createMessageFn({ chatId, content: newMessage });
    setNewMessage('');
  };

  return (
    <div className=''>
      <div className=''>
        {messages.map((message) => (
          <div
            key={message.id}
            className=''
          >
            <p>{message.content}</p>
          </div>
        ))}
      </div>
      <div className=''>
        <input
          type='text'
          placeholder='New Message'
          className=''
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button
          onClick={handleCreateMessage}
          className=''
        >
          Send
        </button>
      </div>
    </div>
  );
}